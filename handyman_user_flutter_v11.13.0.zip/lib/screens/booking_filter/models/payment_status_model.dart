class PaymentStatusModel {
  String? status;
  bool isSelected = false;

  PaymentStatusModel({this.status});
}